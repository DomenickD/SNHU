package com.example.weighttrackerapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        dbHelper = new DatabaseHelper(getContext());

        EditText usernameEditText = view.findViewById(R.id.username);
        EditText passwordEditText = view.findViewById(R.id.password);
        Button loginButton = view.findViewById(R.id.login_button);
        Button registerButton = view.findViewById(R.id.register_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                if (dbHelper.checkUser(username, password)) {
                    Toast.makeText(getContext(), "Login successful", Toast.LENGTH_SHORT).show();
                    // Navigate to Data Display Fragment
                    ((MainActivity) getActivity()).loadFragment(new DataDisplayFragment());
                } else {
                    Toast.makeText(getContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getContext(), "Please enter a username and password then click register to register.", Toast.LENGTH_SHORT).show();
                } else {
                    if (dbHelper.registerUser(username, password)) {
                        Toast.makeText(getContext(), "Registration successful. Please log in.", Toast.LENGTH_SHORT).show();
                        // Clear the password field
                        passwordEditText.setText("");
                    } else {
                        Toast.makeText(getContext(), "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        return view;
    }
}
