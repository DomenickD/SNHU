package com.example.weighttrackerapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DataDisplayFragment extends Fragment {
    private DatabaseHelper dbHelper;
    private SimpleCursorAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_data_display, container, false);

        dbHelper = new DatabaseHelper(getContext());

        ListView listView = view.findViewById(R.id.data_table);
        Button addButton = view.findViewById(R.id.add_data_button);
        Button displayButton = view.findViewById(R.id.display_data_button);
        Button logoutButton = view.findViewById(R.id.logout_button);
        Button goalButton = view.findViewById(R.id.goal_weight_button);
        EditText dateEditText = view.findViewById(R.id.date);
        EditText weightEditText = view.findViewById(R.id.weight);
        CheckBox todayCheckbox = view.findViewById(R.id.today_checkbox);

        String[] from = {DatabaseHelper.COLUMN_DATE, DatabaseHelper.COLUMN_WEIGHT};
        int[] to = {R.id.date, R.id.weight};

        adapter = new SimpleCursorAdapter(getContext(), R.layout.weight_item, null, from, to, 0);
        listView.setAdapter(adapter);

        todayCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                dateEditText.setText(todayDate);
                dateEditText.setEnabled(false);
            } else {
                dateEditText.setText("");
                dateEditText.setEnabled(true);
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = dateEditText.getText().toString().trim();
                double weight = Double.parseDouble(weightEditText.getText().toString().trim());
                if (dbHelper.addWeight(date, weight)) {
                    Toast.makeText(getContext(), "Weight added successfully", Toast.LENGTH_SHORT).show();
                    loadWeights();
                } else {
                    Toast.makeText(getContext(), "Failed to add weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadWeights();
            }
        });

        goalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).loadFragment(new GoalWeightFragment());
            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).loadFragment(new LoginFragment());
            }
        });

        return view;
    }

    private void loadWeights() {
        Cursor cursor = dbHelper.getAllWeights();
        adapter.changeCursor(cursor);
    }
}
