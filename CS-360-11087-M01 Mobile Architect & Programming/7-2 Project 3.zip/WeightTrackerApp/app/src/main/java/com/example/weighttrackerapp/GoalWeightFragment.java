package com.example.weighttrackerapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class GoalWeightFragment extends Fragment {
    private DatabaseHelper dbHelper;
    private TextView goalWeightTextView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_goal_weight, container, false);

        dbHelper = new DatabaseHelper(getContext());

        EditText goalWeightEditText = view.findViewById(R.id.goal_weight);
        Button setGoalButton = view.findViewById(R.id.set_goal_button);
        Button backButton = view.findViewById(R.id.back_button);
        Button logoutButton = view.findViewById(R.id.logout_button);
        goalWeightTextView = view.findViewById(R.id.goal_weight_text);

        loadGoalWeight();

        setGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double goalWeight = Double.parseDouble(goalWeightEditText.getText().toString().trim());
                if (dbHelper.setGoalWeight(goalWeight)) {
                    Toast.makeText(getContext(), "Goal weight set successfully", Toast.LENGTH_SHORT).show();
                    loadGoalWeight();
                } else {
                    Toast.makeText(getContext(), "Failed to set goal weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).loadFragment(new DataDisplayFragment());
            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).loadFragment(new LoginFragment());
            }
        });

        return view;
    }

    private void loadGoalWeight() {
        double goalWeight = dbHelper.getGoalWeight();
        if (goalWeight == -1) {
            goalWeightTextView.setText("No goal weight set");
        } else {
            goalWeightTextView.setText("Goal Weight: " + goalWeight);
        }
    }
}
